cd ..
rm input.txt
python3 nnc.py
