OR is non deterministic
XOR doesn't work
